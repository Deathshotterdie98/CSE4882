<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>

  <div class="topnav">
  <a class="active" href="index.php">Home</a>
  <a href="New%20addition/contact_us_email_enabled/contact_us.php">Contact</a>
  <a href="about_us.php">About Us</a>
  <a href="logout.php">Log out</a>
</div>

  <link rel="stylesheet" type="text/css" href="css/as.css">
</head>
<body>
<?php
       $un=$_SESSION['un'];
       if(!$un)
       {
         header("Location:login.php");
       }
      ?>
  
  <br><br><br><br>
<div>
  <br>
<p align="center" style="font-family: sans-serif; font-size: 25px; color: white;">User Data List</p>
<br>
<table id="customers" style="margin: 0px auto;">
  <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Username</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>More Information</th>
  </tr>
  <?php
$q=$db->query("SELECT * FROM users");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
  ?>
    <tr>
    <td><?= $p->user_id; ?></td>
    <td><?= $p->firstname; ?></td>
    <td><?= $p->lastname; ?></td>
    <td><?= $p->username; ?></td>
    <td><?= $p->email; ?></td>
    <td><?= $p->phonenumber; ?></td>
    <td><?= $p->moreinformation; ?></td>
   
  </tr>
  <?php
}
   ?>
 </table>
</div>

<div>
  <br><br><br>
<p align="center" style="font-family: sans-serif; font-size: 25px; color: white;">Driver's Data List</p>
<br>
<table id="customers" style="margin: 0px auto;">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Phone Number</th>
    <th>Seat Number</th>
    <th>Address</th>
    <th>Car Name</th>
  </tr>
  <?php
$q=$db->query("SELECT * FROM driver_list");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
  ?>
    <tr>
    <td><?= $p->id; ?></td>
    <td><?= $p->name; ?></td>
    <td><?= $p->gender; ?></td>
    <td><?= $p->number; ?></td>
    <td><?= $p->seats; ?></td>
    <td><?= $p->address; ?></td>
    <td><?= $p->car_name; ?></td>
   
  </tr>
  <?php
}
   ?>
 </table>
</div>
</body>
</html>
