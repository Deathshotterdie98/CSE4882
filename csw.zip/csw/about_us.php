
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>About Us card || Learning robo</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/about_us.css">
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <section>
            <div class = "image">
               <img src="group.jpg">
            </div>

            <div class = "content">
                <h2>About Us</h2>
                <span><!-- line here --></span>
                <p>
                    We are group of students who are aiming to complete this beautiful project and serve general people. Our final goal is to provide the best service to the user who will use our product. 
                    <br/>
                    <br>Please let us know your opinion by <em>Contacting with Us</em></br>
                </p>
                <ul class = "links">
                    <li><a href = "contact_us.php">Contact Us</a></li>
                </ul>
                <ul class = "icons">
                    <li>
                        <a href="https://github.com/Deathshotterdie98/CSE4882"><i class = "fa fa-github"></i></a>
                    </li>
                </ul>
            </div>
       
    </body>
</html>
