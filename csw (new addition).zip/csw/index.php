<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>

  <div class="topnav">
  <a class="active" href="index.php">Home</a>
  <a href="New%20addition/contact_us_email_enabled/contact_us.php">Contact</a>
  <a href="about_us.php">About</a>
  <a href="signup.php">Sign Up</a>
  <a href="login.php">Login</a>
</div>

  <div class="banner-text">
    <h1>Car Sharing</h1>
    <p>Plan your next trip now
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
 


</body>
</html>
