<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>

  <div class="topnav">
  <a class="active" href="d.php">Home</a>
  <a href="New%20addition/contact_us_email_enabled/contact_us.php">Contact</a>
  <a href="about_us.php">About Us</a>
  <a href="logout.php">Log out</a>
</div>

  <link rel="stylesheet" type="text/css" href="css/ad.css">
</head>
<body>
  
  
 
</body>
</html>
