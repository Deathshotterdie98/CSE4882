<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<div class="banner-text">
		<h1>Driver Registration</h1>
	<link rel="stylesheet" type="text/css" href="css/s9.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<br>
      <br><br><br>
      <center><div id="form">
        <form action="" method="post">
        <table>
         <label for="first" >Full Name:</label>
	<input id="first" type="text" name="name" placeholder="Full Name"  autofocus required />

	<br /><br />

	<label for="Gender">Gender:</label>
	<input type="radio" name="gender" value="Male"/>Male
	<input type="radio" name="gender" value="Female"/>Female
	<input type="radio" name="gender" value="Others"/>Others

	<br /><br />

	<label for="phone">Phone Number:</label>
	<input id="phone" type="text" name="number"placeholder="+8801********" required />

	<br /><br />

	<label>Seats:</label>

	<select name="seats" style="border-radius: 10px">
		<option>Select</option>
		<option>0</option>
		<option>1</option>
		<option>2</option>
		<option>3</option>
		<option>4</option>
	
		</select>

	<br /><br />

	<label for="address">Address:</label>
	<textarea name="address" id="address" placeholder="Please include your Division & City" cols="35" rows="2"></textarea>
	
	<br /><br />

	 <label for="first" >Car Name:</label>
	<input id="first" type="text" name="car_name" placeholder="Car Name"  autofocus required />
	<br /><br />

	 <label for="first" >pick up:</label>
	<input id="first" type="text" name="pick_up" placeholder="pick up"  autofocus required />
	<br /><br />

	 <label for="first" >drop out:</label>
	<input id="first" type="text" name="drop_out" placeholder="drop out"  autofocus required />




</div>


<br>
<?php include 'map.php'; ?>
	</form>
	<br />

    <?php
    if(isset($_POST['sub'])){
    	$id=uniqid();
        $name=$_POST['name'];
        $gender=@$_POST['gender'];
        $number=$_POST['number'];
        $seats=$_POST['seats'];
        $address=$_POST['address'];
        $car_name=$_POST['car_name'];
        $pick_up=$_POST['pick_up'];
        $drop_out=$_POST['drop_out'];
				

        $q=$db->prepare("INSERT INTO driver_list(id,name,gender,number,seats,address,car_name,pick_up,drop_out) VALUES (:id,:name,:gender,:number,:seats,:address,:car_name,:pick_up,:drop_out)");

        $q->bindValue('id',$id);
        $q->bindValue('name',$name);
        $q->bindValue('gender',$gender);
        $q->bindValue('number',$number);
        $q->bindValue('seats',$seats);
        $q->bindValue('address',$address);
        $q->bindValue('car_name',$car_name);
        $q->bindValue('pick_up',$pick_up);
        $q->bindValue('drop_out',$drop_out);

        if($q->execute()){
                    $latitude=$_POST['latitude'];
					$longitude=$_POST['longitude'];
					$l=$db->prepare("INSERT INTO location(id,latitude,longitude) VALUES (:id,:latitude,:longitude)");
					$l->bindValue('id',$id);
					$l->bindValue('latitude',$latitude);
					$l->bindValue('longitude',$longitude);

        if($l->execute()){
	          echo "<script>alert('Registration Succesfull!')</script>";
              }
        }
        else{
            echo "<script>alert('Registration Failed!')</script>";
        }
    }

    ?>
      </div></center>
    </div>

	

</body>
</html>